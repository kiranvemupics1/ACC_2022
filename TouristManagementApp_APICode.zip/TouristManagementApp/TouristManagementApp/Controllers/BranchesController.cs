﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TouristManagementApp.Models;
using TouristManagementApp.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TouristManagementApp.Controllers
{

    [EnableCors("MyPolicy")]
    [Route("tourism/api/v1/branch/")]
    [ApiController]
    public class BranchesController : ControllerBase
    {
        private readonly IBranchService _branchService;

        public BranchesController(IBranchService branchService)
        {
            this._branchService = branchService;
        }

        // GET: api/<BranchesController>
        [Route("all-branches")]
        [HttpGet]
        public ActionResult<List<Branch>> Get()
        {
            return _branchService.Get();
        }

        // GET api/<BranchesController>/5
        [HttpGet("{id}")]
        public ActionResult<Branch> Get(string id)
        {
            var branch =  _branchService.Get(id);

            if(branch == null)
            {
                return NotFound($"Branch with Id - {id} not found");
            }

            return branch;
        }

        // POST api/<BranchesController>
        [Route("all-places")]
        [HttpPost]
        public ActionResult<Branch> Post([FromBody] Branch branch)
        {
            _branchService.Create(branch);

            return CreatedAtAction(nameof(Get), new { id = branch.Id}, branch);
        }

        //// PUT api/<BranchesController>/5
        //[HttpPut("{id}")]
        //public ActionResult Put(string id, [FromBody] Branch branch)
        //{
        //    var existingBranch = _branchService.Get(id);

        //    if(existingBranch == null)
        //    {
        //        return NotFound($"Branch with Id - {id} not found");
        //    }

        //    _branchService.Update(id, branch);

        //    return NoContent();
        //}

        // PUT api/<BranchesController>/5
        //[Route("update-tariff")]
        [HttpPut("update-tariff/{companyID}")]
        public ActionResult updateTariff(string companyID, [FromBody] Tariff tariffValue)
        {
            var existingBranch = _branchService.Get(companyID);

            if (existingBranch == null)
            {
                return NotFound($"Branch with Id - {companyID} not found");
            }

            existingBranch.Tariff = tariffValue.TariffValue;

            _branchService.Update(companyID, existingBranch);

            return NoContent();
        }

        // DELETE api/<BranchesController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(string id)
        {
            var existingBranch = _branchService.Get(id);

            if (existingBranch == null)
            {
                return NotFound($"Branch with Id - {id} not found");
            }

            _branchService.Remove(id);

            return Ok($"Branch with Id - {id} deleted");
        }
    }
}
