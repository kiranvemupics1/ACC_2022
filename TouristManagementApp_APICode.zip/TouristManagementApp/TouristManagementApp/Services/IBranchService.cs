﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TouristManagementApp.Models;

namespace TouristManagementApp.Services
{
    public interface IBranchService
    {
        List<Branch> Get();
        Branch Get(string id);
        Branch Create(Branch branch);
        void Update(string id, Branch branch);
        void Remove(string id);
    }
}
