﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TouristManagementApp.Models;
using MongoDB.Driver;

namespace TouristManagementApp.Services
{
    public class BranchService : IBranchService
    {
        private readonly IMongoCollection<Branch> _branches;

        public BranchService(IBranchStoreDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _branches = database.GetCollection<Branch>(settings.BranchesCollectionName);
        }
        public Branch Create(Branch branch)
        {
            _branches.InsertOne(branch);

            return branch;
        }

        public List<Branch> Get()
        {
            return _branches.Find(branch => true).ToList();
        }

        public Branch Get(string id)
        {
            return _branches.Find(branch => branch.Id == id).FirstOrDefault();
        }

        public void Remove(string id)
        {
            _branches.DeleteOne(branch => branch.Id == id);
        }

        public void Update(string id, Branch branch)
        {
            _branches.ReplaceOne(branch => branch.Id == id, branch);
        }
    }
}
