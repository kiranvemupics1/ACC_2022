﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace TouristManagementApp.Models
{
    [BsonIgnoreExtraElements]
    public class Tariff
    {
        public int TariffValue { get; set; }
    }
}
