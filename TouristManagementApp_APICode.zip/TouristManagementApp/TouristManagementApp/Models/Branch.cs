﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace TouristManagementApp.Models
{
    [BsonIgnoreExtraElements]
    public class Branch
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = String.Empty;
        [BsonElement("name")]
        public string Name { get; set; } = String.Empty;
        [BsonElement("place")]
        public string Place { get; set; } = String.Empty;
        [BsonElement("website")]
        public string Website { get; set; } = String.Empty;
        [BsonElement("contact")]
        public int Contact { get; set; }
        [BsonElement("tariff")]
        public int Tariff { get; set; }
        [BsonElement("email")]
        public string Email { get; set; } = String.Empty;
    }
}
